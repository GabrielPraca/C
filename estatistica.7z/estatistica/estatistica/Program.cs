﻿using System;
using System.Collections.Generic;
using System.Text;

namespace estatistica
{
    class Program
    {
        static void Main(string[] args)
        {
            float Som = 0;
            float Som2 = 0;
            int QntEle = 0;
            float media = 0;
            float variancia = 0;
            float desviop = 0;

            Console.Title = "Média, Variância e Desvio Padrão";

            Console.Write("digite o somatório: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Som = (float)Convert.ToDouble(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Gray;

            Console.Write("digite o somatório ao quadrado: ");
            Console.ForegroundColor = ConsoleColor.Red;
            Som2 = (float)Convert.ToDouble(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("digite a quantidade de elementos: ");
            Console.ForegroundColor = ConsoleColor.Green;
            QntEle = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Gray;

            //Calcula média
            media = Som / QntEle;

            //calcula a variãncia
            variancia = (Som2 - QntEle * (media * media)) / (QntEle - 1);

            //desvio padrão
            desviop = (float)Math.Sqrt(variancia);

            //mostra ao usuario
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n média é: " + String.Format("{0:0.00}", media));
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" variancia é: " + String.Format("{0:0.00}", variancia));
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" desvio padrao é: " +  String.Format("{0:0.00}", desviop));

            Console.ReadKey();
        }        
    }
}
