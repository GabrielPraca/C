﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrganizarVetor
{
    class Program
    {
        static void Main(string[] args)
        {
            int qntN = 0;
            int nres = 0;
            int va = 0;
            int ii = 0;
            int i = 0;
            int[] vetorzinho;

            Console.WriteLine("Digite a quantidade de números");
            qntN = Convert.ToInt32(Console.ReadLine());
            vetorzinho = new int [qntN];
            nres = qntN;
            Console.Clear();

            while(i < vetorzinho.Length)
            {
                Console.WriteLine("digite um valor: " + "               valores restantes: " + nres);
                vetorzinho[i] = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                i++;
                nres--;
            }
            i = 0;
            //antes de organizar
            Console.Write("os valores não organizados são: ");
            while (i < vetorzinho.Length)
            {
                if (i == 0)
                    Console.Write(vetorzinho[i]);
                else
                    Console.Write(", " + vetorzinho[i]);
                i++;
            }
            while (ii < vetorzinho.Length)
            {
                i = 0;
                while (i < vetorzinho.Length - 1)
                {
                    if (vetorzinho[i] > vetorzinho[i + 1])
                    {
                        va = vetorzinho[i];
                        vetorzinho[i] = vetorzinho[i + 1];
                        vetorzinho[i + 1] = va;
                    }
                    i++;
                }

                ii++;
            }

            i = 0;
            //antes de organizar
            Console.Write("\n\nos valores organizados são: ");
                while (i < vetorzinho.Length)
                {
                    if (i == 0)
                        Console.Write(vetorzinho[i]);
                    else
                        Console.Write(", " + vetorzinho[i]);
                    i++;
                }

            Console.ReadKey();
        }
    }
}